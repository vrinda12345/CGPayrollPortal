package com.cg.banking.controller;

import java.io.IOException;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServiceDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

@WebServlet("/withdrawalAmount")
public class WithdrawalAmountServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	private BankingServices services;

	@Override
	public void init() throws ServletException {
		services=new BankingServicesImpl();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int accountNo = Integer.parseInt(request.getParameter("accountNo"));
		float withdrawalAmount = Float.parseFloat(request.getParameter("withdrawalAmount"));
		int pinNumber = Integer.parseInt(request.getParameter("pinNumber"));
		try {
			float updatedBalance = services.withdrawAmount(accountNo, withdrawalAmount, pinNumber);
			request.setAttribute("updatedBalance", updatedBalance);
			request.getRequestDispatcher("withdrawAmountSuccess.jsp").forward(request, response);
		} catch (InsufficientAmountException e) {
			request.setAttribute("error", e.getMessage());
			request.getRequestDispatcher("withdrawAmount.jsp").forward(request, response);
			
		} catch (AccountNotFoundException e) {
			request.setAttribute("error", e.getMessage());
			request.getRequestDispatcher("withdrawAmount.jsp").forward(request, response);
		} catch (InvalidPinNumberException e) {
			request.setAttribute("error", e.getMessage());
			request.getRequestDispatcher("withdrawAmount.jsp").forward(request, response);
		} catch (BankingServiceDownException e) {
			request.setAttribute("error", e.getMessage());
			request.getRequestDispatcher("withdrawAmount.jsp").forward(request, response);
		} catch (AccountBlockedException e) {
			request.setAttribute("error", e.getMessage());
			request.getRequestDispatcher("withdrawAmount.jsp").forward(request, response);
		}
		
	}
	public void destroy() {
		services = null;
	}

}
