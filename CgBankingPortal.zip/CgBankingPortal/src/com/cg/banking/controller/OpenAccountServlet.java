package com.cg.banking.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.banking.beans.Account;
import com.cg.banking.exceptions.BankingServiceDownException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

@WebServlet(urlPatterns="/openAccount",loadOnStartup=1)
public class OpenAccountServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private BankingServices services;
    
    @Override
	public void init() throws ServletException {
		services=new BankingServicesImpl();
		
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
		String accountType = request.getParameter("accountType");
		float initBalance = Float.parseFloat(request.getParameter("initBalance"));
		try {
			Account account = services.openAccount(accountType, initBalance);
			request.setAttribute("account", account);
			request.getRequestDispatcher("getAccountDetailsSuccess.jsp").forward(request, response);
		} catch (InvalidAmountException e) {
			request.setAttribute("error",e.getMessage());
			request.getRequestDispatcher("openAccount.jsp").forward(request, response);
		} catch (InvalidAccountTypeException e) {
			request.setAttribute("error",e.getMessage());
			request.getRequestDispatcher("openAccount.jsp").forward(request, response);
		} catch (BankingServiceDownException e) {
			request.setAttribute("error",e.getMessage());
			request.getRequestDispatcher("openAccount.jsp").forward(request, response);
		}
	}
	@Override
	public void destroy() {
		services = null;
	}
    

}
